  let a = document.getElementById('cont')
document.getElementById('c').addEventListener('click',function(){
  a.innerText=''
})
document.getElementById('de').addEventListener('click',function(){
  a.innerText=a.innerText.toString().slice(0,-1)
})

document.getElementById('7').addEventListener('click',function(){
  a.innerText+=7
})
document.getElementById('8').addEventListener('click',function(){
  a.innerText+=8
})
document.getElementById('9').addEventListener('click', function() {
  a.innerText += 9
})
document.getElementById('×').addEventListener('click', function() {
  a.innerText += '*'
})
document.getElementById('4').addEventListener('click', function() {
  a.innerText += 4
})
document.getElementById('5').addEventListener('click', function() {
  a.innerText += 5
})
document.getElementById('6').addEventListener('click', function() {
  a.innerText += 6
})
document.getElementById('-').addEventListener('click', function() {
  a.innerText += '-'
})
document.getElementById('1').addEventListener('click', function() {
  a.innerText += 1
})
document.getElementById('2').addEventListener('click', function() {
  a.innerText += 2
})

  document.getElementById('3').addEventListener('click', function() {
    a.innerText += 3
  })
  document.getElementById('+').addEventListener('click', function() {
    a.innerText += '+'
  })
  
  document.getElementById('0').addEventListener('click', function() {
    a.innerText += 0
  })
document.getElementById('.').addEventListener('click', function() {
  a.innerText += '.'
})
document.getElementById('=').addEventListener('click', function() {
  a.innerText = eval(a.innerText)
})

document.getElementById('÷').addEventListener('click', function() {
  a.innerText += '/'
})

  


  


  


  